// Punto de entrada de toda la interfaz: rutas, pantallas y estado del carrito.
import { useEffect, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Link, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import {
  ArrowLeft, ArrowRight, Banknote, BarChart3, Bike, Check, ChevronDown, CircleUserRound, Clock3, CreditCard, LogOut,
  Flame, MapPin, Menu, Minus, MoreHorizontal, PackageCheck, Plus, Search,
  ShoppingBag, SlidersHorizontal, Star, Store, Tag, TrendingUp, UserRound, Users, Utensils, Wallet,
} from 'lucide-react';
import {
  getGetDashboardSummaryQueryKey, getGetOrderQueryKey, getListOrdersQueryKey,
  getListRestaurantProductsQueryKey, useCreateOrder,
  useGetDashboardSummary, useGetOrder, useListOrders, useListRestaurantProducts,
  useListRestaurants, useUpdateOrderStatus, useHealthCheck,
} from '@workspace/api-client-react';
import type {
  DashboardSummary, Order, OrderItem, OrderStatus, OrderStatusInputStatus, Product, Restaurant,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Sheet, SheetContent, SheetDescription, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import NotFound from '@/pages/not-found';
import SystemMapPage from '@/pages/system-map';
import { clearSession, RoleAuthPage, RoleGate, roleHome, readSession } from '@/pages/role-access';
import AdminManagementPage from '@/pages/admin-management';
import EnhancedDeliveryPortalPage from '@/pages/delivery-portal';
import BusinessPortalPage from '@/pages/business-portal';

// React Query administra las consultas al API y permite refrescar datos
// después de crear un pedido o cambiar su estado.
const queryClient = new QueryClient();

// Datos de respaldo para que la experiencia siga siendo navegable
// mientras el API está cargando o si todavía no tiene registros.
const fallbackRestaurants: Restaurant[] = [
  { id: 1, name: 'Sazón de la Plaza', cuisine: 'Criolla & selvática', rating: 4.8, deliveryMinutes: 28, deliveryFee: 3.5, isOpen: true, featured: true, image: '/restaurant-selva.jpg' },
  { id: 2, name: 'Cevichería La Ribera', cuisine: 'Marina / ceviches', rating: 4.7, deliveryMinutes: 22, deliveryFee: 4, isOpen: true, featured: true, image: '/restaurant-cebicheria.jpg' },
  { id: 3, name: 'El Fogón de Tere', cuisine: 'Pollos & brasas', rating: 4.6, deliveryMinutes: 31, deliveryFee: 3, isOpen: true, image: '/restaurant-brasa.jpg' },
  { id: 4, name: 'Café Pangoa', cuisine: 'Café & desayunos', rating: 4.5, deliveryMinutes: 18, deliveryFee: 2.5, isOpen: false, image: '/restaurant-cebicheria.jpg' },
];
const fallbackProducts: Product[] = [
  { id: 101, restaurantId: 1, name: 'Tacacho con cecina', description: 'Plátano asado, cecina ahumada y salsa de cocona.', price: 26, category: 'Favoritos', image: '/restaurant-selva.jpg', popular: true },
  { id: 102, restaurantId: 1, name: 'Juane de la casa', description: 'Arroz sazonado, gallina y huevo envuelto en bijao.', price: 22, category: 'Favoritos', image: '/restaurant-selva.jpg', popular: true },
  { id: 103, restaurantId: 1, name: 'Chapo de plátano', description: 'Bebida tibia de plátano maduro con canela.', price: 9, category: 'Bebidas', image: '/restaurant-selva.jpg', popular: false },
  { id: 201, restaurantId: 2, name: 'Ceviche clásico', description: 'Pesca del día, leche de tigre, cancha y camote.', price: 29, category: 'Más pedidos', image: '/restaurant-cebicheria.jpg', popular: true },
  { id: 202, restaurantId: 2, name: 'Chicharrón de pota', description: 'Crujiente, fresco y con salsa tártara de la casa.', price: 24, category: 'Más pedidos', image: '/restaurant-cebicheria.jpg', popular: true },
  { id: 203, restaurantId: 2, name: 'Limonada hierbaluisa', description: 'Limón recién exprimido y hierbaluisa local.', price: 8, category: 'Bebidas', image: '/restaurant-cebicheria.jpg', popular: false },
  { id: 301, restaurantId: 3, name: 'Pollo a la brasa entero', description: 'Marinado 24 horas, papas doradas y ensalada criolla.', price: 48, category: 'Para compartir', image: '/restaurant-brasa.jpg', popular: true },
];

type CartLine = Product & { quantity: number; restaurantName: string };
type Notice = { type: 'success' | 'error'; text: string } | null;

// Utilidades compartidas para precios, fechas y etiquetas de estado.
const money = (value: number) => `S/ ${value.toFixed(2)}`;
const dateLabel = (value: string) => new Intl.DateTimeFormat('es-PE', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
const normalizeSearchText = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
const statusLabel: Record<string, string> = { received: 'Recibido', preparing: 'En cocina', ready: 'Listo', on_the_way: 'En camino', delivered: 'Entregado', cancelled: 'Cancelado' };
const statusTone: Record<string, string> = {
  received: 'bg-amber-100 text-amber-800', preparing: 'bg-orange-100 text-orange-800', ready: 'bg-sky-100 text-sky-800',
  on_the_way: 'bg-fuchsia-100 text-fuchsia-800', delivered: 'bg-violet-100 text-violet-800', cancelled: 'bg-red-100 text-red-800',
};

// Hook del carrito: lo guarda en localStorage para conservarlo al recargar
// y evita mezclar productos de restaurantes diferentes en un mismo pedido.
function useCart() {
  const [cart, setCart] = useState<CartLine[]>(() => {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem('pq-cart') || '[]');
      if (!Array.isArray(saved)) return [];
      return saved.filter((line): line is CartLine => line && Number.isFinite(line.id) && Number.isFinite(line.restaurantId) && Number.isFinite(line.price) && line.price >= 0 && Number.isInteger(line.quantity) && line.quantity > 0 && typeof line.name === 'string' && typeof line.restaurantName === 'string');
    } catch { return []; }
  });
  useEffect(() => { localStorage.setItem('pq-cart', JSON.stringify(cart)); }, [cart]);
  const add = (product: Product, restaurantName: string) => setCart((current) => {
    if (!Number.isFinite(product.id) || !Number.isFinite(product.restaurantId) || !Number.isFinite(product.price) || product.price < 0) return current;
    const found = current.find((line) => line.id === product.id);
    if (current.length && current[0].restaurantId !== product.restaurantId) return [{ ...product, quantity: 1, restaurantName }];
    return found ? current.map((line) => line.id === product.id ? { ...line, quantity: line.quantity + 1 } : line) : [...current, { ...product, quantity: 1, restaurantName }];
  });
  const update = (id: number, amount: number) => {
    if (!Number.isFinite(amount)) return;
    setCart((current) => current.map((line) => line.id === id ? { ...line, quantity: Math.max(0, Math.floor(amount)) } : line).filter((line) => line.quantity > 0));
  };
  return { cart, add, update, clear: () => setCart([]) };
}

function Mark() {
  return <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary shadow-sm"><Utensils className="h-4 w-4" strokeWidth={2.5} /></span>;
}

// Encabezado público usado por las pantallas del cliente.
function CustomerHeader({ cartCount }: { cartCount: number }) {
  const [location, setLocation] = useLocation();
  const logout = () => {
    clearSession();
    setLocation('/login');
  };
  return <header className="sticky top-0 z-30 border-b border-border/70 bg-[hsl(var(--background)/.94)] backdrop-blur-md">
    <div className="mx-auto flex h-[72px] max-w-[1400px] items-center gap-4 px-5 lg:px-9">
      <Link href="/" className="group flex items-center gap-3" data-testid="link-home">
        <Mark /><span className="font-display text-[19px] font-bold tracking-[-.04em] text-primary">QUILLAYAA<span className="text-accent">.</span></span>
      </Link>
      <div className="hidden items-center gap-7 pl-8 text-[13px] font-bold text-muted-foreground md:flex">
        <Link href="/" data-testid="link-discover" className={location === '/' ? 'text-primary' : 'hover:text-primary'}>Descubrir</Link>
        <Link href="/orders" data-testid="link-orders" className={location.startsWith('/orders') ? 'text-primary' : 'hover:text-primary'}>Mis pedidos</Link>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <div className="hidden items-center gap-2 rounded-full bg-card px-3 py-2 text-xs font-semibold text-muted-foreground ring-1 ring-border md:flex"><MapPin className="h-3.5 w-3.5 text-accent" /> Quillabamba, Cusco <ChevronDown className="h-3.5 w-3.5" /></div>
        <Link href="/cart" className="relative flex h-10 w-10 items-center justify-center rounded-full bg-card text-primary ring-1 ring-border transition hover:-translate-y-0.5 hover:ring-secondary" data-testid="link-cart"><ShoppingBag className="h-[18px] w-[18px]" />{cartCount > 0 && <span className="absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-accent px-1 font-mono-app text-[10px] font-bold text-white">{cartCount}</span>}</Link>
         <Link href="/settings" className="hidden h-10 items-center gap-2 rounded-full bg-primary px-3.5 text-xs font-bold text-primary-foreground transition hover:bg-primary/90 sm:flex" data-testid="link-settings"><CircleUserRound className="h-4 w-4" /> Mi cuenta</Link>
         <button onClick={logout} className="flex h-10 items-center gap-2 rounded-full border border-border bg-card px-3 text-xs font-bold text-primary transition hover:border-accent hover:text-accent" aria-label="Cerrar sesión" data-testid="button-customer-logout"><LogOut className="h-4 w-4" /><span className="hidden sm:inline">Salir</span></button>
      </div>
    </div>
     <nav className="mx-auto flex max-w-[1400px] items-center justify-around border-t border-border/70 px-3 md:hidden" aria-label="Navegación del cliente">
       <Link href="/" className={`flex min-h-12 items-center gap-1.5 px-2 text-xs font-bold ${location === '/' ? 'text-primary' : 'text-muted-foreground'}`} aria-current={location === '/' ? 'page' : undefined}><Store className="h-4 w-4" /> Descubrir</Link>
       <Link href="/orders" className={`flex min-h-12 items-center gap-1.5 px-2 text-xs font-bold ${location.startsWith('/orders') ? 'text-primary' : 'text-muted-foreground'}`} aria-current={location.startsWith('/orders') ? 'page' : undefined}><PackageCheck className="h-4 w-4" /> Mis pedidos</Link>
       <Link href="/settings" className={`flex min-h-12 items-center gap-1.5 px-2 text-xs font-bold ${location === '/settings' ? 'text-primary' : 'text-muted-foreground'}`} aria-current={location === '/settings' ? 'page' : undefined}><CircleUserRound className="h-4 w-4" /> Mi cuenta</Link>
     </nav>
  </header>;
}

// Contenedor común para las pantallas internas de administración.
function AdminShell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const session = readSession();
  const health = useHealthCheck();
  void health;
  const logout = () => {
    clearSession();
    setLocation('/login');
  };
  const nav = [
    { href: '/admin', label: 'Resumen', icon: TrendingUp },
    { href: '/admin/orders', label: 'Pedidos', icon: PackageCheck },
    { href: '/admin/restaurants', label: 'Restaurantes', icon: Store },
    { href: '/admin/delivery', label: 'Repartidores', icon: Bike },
    { href: '/admin/system', label: 'Mapa del sistema', icon: TrendingUp },
    { href: '/admin/manage', label: 'Gestión integral', icon: SlidersHorizontal },
  ];
  const sidebarContent = <>
      <Link href="/admin" onClick={() => setMobileMenuOpen(false)} className="mb-12 flex items-center gap-3 px-3" data-testid="link-admin-brand"><Mark /><span className="font-display text-lg font-bold">QUILLAYAA<span className="text-sidebar-foreground">.</span></span></Link>
      <p className="px-3 pb-3 font-mono-app text-[10px] uppercase tracking-[.16em] text-sidebar-foreground/75">Operaciones</p>
      <nav aria-label="Operaciones de administración" className="space-y-1">{nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileMenuOpen(false)} aria-current={location === href ? 'page' : undefined} data-testid={`link-admin-${label.toLowerCase()}`} className={`flex min-h-11 items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-bold transition ${location === href ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm' : 'text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`}><Icon className="h-[17px] w-[17px]" />{label}</Link>)}</nav>
      <div className="mt-auto pt-6"><div className="rounded-2xl bg-sidebar-accent p-4"><div className="mb-3 flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-white">{session?.name?.slice(0, 2).toUpperCase() || 'AS'}</div><p className="text-xs font-bold">{session?.name || 'Administrador'}</p><p className="mt-1 text-[11px] text-sidebar-foreground/75">Administrador del sistema</p><Link href="/admin/manage" onClick={() => setMobileMenuOpen(false)} className="mt-2 flex min-h-11 items-center text-[11px] font-bold text-sidebar-foreground" data-testid="link-admin-settings">Configuración →</Link></div></div>
  </>;
  return <div className="min-h-[100dvh] bg-[#f1efe7] md:flex">
    <aside className="hidden w-[244px] shrink-0 flex-col bg-sidebar px-4 py-6 text-sidebar-foreground md:flex">{sidebarContent}</aside>
    <div className="min-w-0 flex-1">
      <div className="flex h-16 items-center justify-between gap-2 border-b border-border/60 bg-[#f7f5ee] px-4 md:px-8">
        <div className="flex min-w-0 items-center gap-3">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild><button className="flex h-11 shrink-0 items-center gap-1.5 rounded-xl bg-[#ff8a24] px-3 text-xs font-bold text-primary shadow-sm transition hover:bg-[#ffa044] md:hidden" aria-label="Abrir menú de administración" data-testid="button-admin-mobile-menu"><Menu className="h-5 w-5" /><span>Menú</span></button></SheetTrigger>
            <SheetContent side="left" className="flex h-[100dvh] w-[min(300px,88vw)] flex-col overflow-y-auto border-none bg-sidebar px-4 py-6 text-sidebar-foreground [&>button]:flex [&>button]:h-11 [&>button]:w-11 [&>button]:items-center [&>button]:justify-center">
              <SheetTitle className="sr-only">Menú de administración</SheetTitle>
              <SheetDescription className="sr-only">Operaciones y configuración del administrador del sistema.</SheetDescription>
              {sidebarContent}
            </SheetContent>
          </Sheet>
          <div className="min-w-0"><p className="font-mono-app text-[9px] uppercase tracking-[.08em] text-muted-foreground sm:text-[10px] sm:tracking-[.14em]">Administrador del sistema</p><p className="truncate text-sm font-extrabold text-primary">{nav.find((n) => n.href === location)?.label || 'Operaciones'}</p></div>
        </div>
        <div className="flex shrink-0 items-center gap-3"><span className="hidden items-center gap-1.5 text-xs font-semibold text-muted-foreground sm:flex"><span className="h-2 w-2 rounded-full bg-violet-500" /> Sistema operativo</span><button onClick={logout} aria-label="Cerrar sesión" className="flex h-11 items-center gap-2 rounded-full bg-primary px-3 text-xs font-bold text-white sm:h-9" data-testid="button-system-admin-logout"><LogOut className="h-3.5 w-3.5" /><span className="hidden sm:inline">Salir</span></button></div>
      </div>
      <main className="mx-auto max-w-[1400px] p-5 md:p-8">{children}</main>
    </div>
  </div>;
}

function LoadingCards({ count = 3 }: { count?: number }) { return <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{Array.from({ length: count }).map((_, i) => <div key={i} className="overflow-hidden rounded-2xl bg-card ring-1 ring-border"><div className="h-40 animate-pulse-soft bg-muted" /><div className="space-y-3 p-4"><div className="h-4 w-2/3 animate-pulse-soft rounded bg-muted" /><div className="h-3 w-1/2 animate-pulse-soft rounded bg-muted" /></div></div>)}</div>; }
function QueryError({ retry }: { retry: () => void }) { return <div className="rounded-2xl border border-red-200 bg-red-50 p-8 text-center"><p className="font-display text-lg font-bold text-red-900">Algo se desconectó.</p><p className="mt-1 text-sm text-red-700/80">No pudimos traer la información. Intenta de nuevo.</p><button onClick={retry} className="mt-4 rounded-full bg-red-700 px-4 py-2 text-xs font-bold text-white" data-testid="button-retry">Reintentar</button></div>; }
function EmptyState({ icon: Icon = ShoppingBag, title, text, action }: { icon?: typeof ShoppingBag; title: string; text: string; action?: ReactNode }) { return <div className="rounded-2xl border border-dashed border-border bg-card/60 px-6 py-14 text-center"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary/60 text-primary"><Icon className="h-6 w-6" /></div><h3 className="mt-5 font-display text-xl font-bold text-primary">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">{text}</p>{action}</div>; }
function Badge({ children, tone = 'default' }: { children: React.ReactNode; tone?: 'default' | 'green' | 'orange' | 'red' }) { const tones = { default: 'bg-muted text-muted-foreground', green: 'bg-violet-100 text-violet-800', orange: 'bg-orange-100 text-orange-800', red: 'bg-red-100 text-red-800' }; return <span className={`inline-flex rounded-full px-2.5 py-1 font-mono-app text-[10px] font-bold uppercase tracking-wide ${tones[tone]}`}>{children}</span>; }

function RestaurantCard({ restaurant }: { restaurant: Restaurant }) {
  return <Link href={`/restaurant/${restaurant.id}`} className="group block overflow-hidden rounded-2xl bg-card ring-1 ring-border/80 transition duration-300 hover:-translate-y-1 hover:ring-secondary warm-shadow" data-testid={`card-restaurant-${restaurant.id}`}>
    <div className="relative h-[178px] overflow-hidden bg-primary"><img src={restaurant.image || '/restaurant-selva.jpg'} alt={restaurant.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /><div className="absolute inset-0 bg-gradient-to-t from-primary/55 via-transparent to-transparent" />{restaurant.featured && <span className="absolute left-3 top-3 rounded-full bg-secondary px-2.5 py-1 font-mono-app text-[10px] font-bold uppercase tracking-wide text-primary">Recomendado</span>}{!restaurant.isOpen && <span className="absolute right-3 top-3 rounded-full bg-primary/85 px-2.5 py-1 font-mono-app text-[10px] font-bold uppercase tracking-wide text-primary-foreground">Cerrado</span>}<div className="absolute bottom-3 left-3 flex items-center gap-1 rounded-full bg-[#f6e6bc] px-2 py-1 text-xs font-extrabold text-primary"><Star className="h-3 w-3 fill-primary" /> {restaurant.rating.toFixed(1)}</div></div>
    <div className="p-4"><div className="flex items-start justify-between gap-2"><div><h3 className="font-display text-lg font-bold leading-tight text-primary">{restaurant.name}</h3><p className="mt-1 text-xs font-semibold text-muted-foreground">{restaurant.cuisine}</p></div><ArrowRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-accent" /></div><div className="mt-4 flex items-center gap-3 border-t border-border/70 pt-3 font-mono-app text-[10px] font-medium uppercase tracking-wide text-muted-foreground"><span className="flex items-center gap-1"><Clock3 className="h-3.5 w-3.5 text-accent" /> {restaurant.deliveryMinutes} min</span><span className="text-border">•</span><span>{restaurant.deliveryFee === 0 ? 'Envío gratis' : `Envío ${money(restaurant.deliveryFee)}`}</span></div></div>
  </Link>;
}

// Inicio: consulta restaurantes, aplica búsqueda/filtros y abre cada menú.
function HomePage({ cart }: { cart: ReturnType<typeof useCart> }) {
  const restaurantsQuery = useListRestaurants();
  const restaurants = restaurantsQuery.data?.length ? restaurantsQuery.data : fallbackRestaurants;
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('Todos');
  const normalizedSearch = normalizeSearchText(search);
  const filtered = restaurants.filter((restaurant) => normalizeSearchText(`${restaurant.name} ${restaurant.cuisine}`).includes(normalizedSearch) && (filter === 'Todos' || restaurant.cuisine.split(/[&,/|]+/).some((tag) => normalizeSearchText(tag) === normalizeSearchText(filter))));
  const categories = ['Todos', ...new Set(restaurants.flatMap((restaurant) => restaurant.cuisine.split(/[&,/|]+/).map((tag) => tag.trim()).filter(Boolean)))];
  return <><CustomerHeader cartCount={cart.cart.reduce((a, b) => a + b.quantity, 0)} /><main className="mx-auto max-w-[1400px] px-5 pb-16 lg:px-9">
    <section className="relative mt-5 overflow-hidden rounded-[28px] bg-primary shadow-[0_18px_50px_hsl(266_76%_25%/.18)]"><img src="/hero-quillabamba.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-55 mix-blend-luminosity" /><div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/85 to-primary/10" /><div className="relative min-h-[350px] px-7 py-10 sm:px-12 sm:py-14 lg:min-h-[390px] lg:w-[64%] lg:px-14"><div className="flex items-center gap-2 font-mono-app text-[10px] font-bold uppercase tracking-[.2em] text-secondary"><span className="h-px w-8 bg-secondary" /> Hecho aquí, para ti</div><h1 className="mt-6 max-w-xl font-display text-4xl font-bold leading-[.98] tracking-[-.055em] text-primary-foreground sm:text-6xl">El sabor de<br /><span className="text-secondary">Quillabamba,</span><br />a tu puerta.</h1><p className="mt-5 max-w-md text-sm leading-6 text-primary-foreground/70 sm:text-base">Pide de tus lugares favoritos y disfruta más tiempo lo que importa.</p><Link href="#restaurantes" className="mt-7 inline-flex items-center gap-2 rounded-full bg-secondary px-5 py-3 text-sm font-extrabold text-primary transition hover:gap-3" data-testid="link-explore">Explorar restaurantes <ArrowRight className="h-4 w-4" /></Link></div><div className="absolute bottom-8 right-10 hidden max-w-[190px] rounded-2xl border border-white/20 bg-primary/45 p-4 backdrop-blur-sm lg:block"><p className="font-mono-app text-[10px] uppercase tracking-wide text-secondary">Ahora mismo</p><p className="mt-2 text-sm font-bold leading-5 text-primary-foreground">34 restaurantes cocinando cerca de ti.</p></div></section>
    <section className="mt-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between" id="restaurantes"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.18em] text-accent">La vuelta empieza aquí</p><h2 className="mt-2 font-display text-3xl font-bold tracking-[-.04em] text-primary">¿Qué se te antoja hoy?</h2></div><div className="relative w-full sm:w-[275px]"><Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Busca un restaurante..." className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20" data-testid="input-search-restaurants" /></div></section>
    <div className="mt-5 flex gap-2 overflow-x-auto pb-1">{categories.map((category) => <button key={category} onClick={() => setFilter(category)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-extrabold transition ${filter === category ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground ring-1 ring-border hover:ring-secondary'}`} data-testid={`button-filter-${category.toLowerCase()}`}>{category}</button>)}</div>
    <div className="mt-7">{restaurantsQuery.isLoading ? <LoadingCards /> : restaurantsQuery.isError && !restaurantsQuery.data ? <QueryError retry={() => restaurantsQuery.refetch()} /> : filtered.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">{filtered.map((r) => <RestaurantCard key={r.id} restaurant={r} />)}</div> : <EmptyState title="No encontramos ese antojo" text="Prueba con otra palabra o vuelve a mirar todos los lugares." action={<button onClick={() => { setSearch(''); setFilter('Todos'); }} className="mt-5 rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground" data-testid="button-clear-search">Limpiar búsqueda</button>} />}</div>
    <section className="mt-14 grid gap-4 md:grid-cols-[1.2fr_.8fr]"><div className="rounded-2xl bg-[#e5dfc8] p-7 sm:p-9"><div className="flex items-center gap-2 text-accent"><Flame className="h-5 w-5" /><span className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em]">Dato local</span></div><h3 className="mt-5 max-w-lg font-display text-2xl font-bold leading-tight text-primary">Los pedidos saben mejor cuando apoyan a los de siempre.</h3><p className="mt-3 max-w-md text-sm leading-6 text-primary/65">Cada compra fortalece a una cocina, una familia y el movimiento de nuestra ciudad.</p></div><div className="flex flex-col justify-between rounded-2xl bg-accent p-7 text-primary-foreground sm:p-9"><Tag className="h-6 w-6" /><div><p className="font-mono-app text-[10px] uppercase tracking-[.16em] text-primary-foreground/65">Primera vuelta</p><h3 className="mt-2 font-display text-2xl font-bold">Envío a S/ 0</h3><p className="mt-2 text-sm text-primary-foreground/75">En restaurantes seleccionados esta semana.</p></div></div></section>
  </main></>;
}

// Menú del restaurante: consulta productos, filtra categorías y añade al carrito.
function RestaurantPage({ cart }: { cart: ReturnType<typeof useCart> }) {
  const { id } = useParams<{ id: string }>();
  const restaurantId = Number(id);
  const restaurantsQuery = useListRestaurants();
  const productsQuery = useListRestaurantProducts(restaurantId, { query: { queryKey: getListRestaurantProductsQueryKey(restaurantId) } });
  const restaurant = (restaurantsQuery.data || fallbackRestaurants).find((r) => r.id === restaurantId) || fallbackRestaurants.find((r) => r.id === restaurantId) || fallbackRestaurants[0];
  const products = productsQuery.data?.length ? productsQuery.data : fallbackProducts.filter((p) => p.restaurantId === restaurant.id);
  const categories = [...new Set(products.map((p) => p.category))];
  const [selectedCategory, setSelectedCategory] = useState('');
  const [notice, setNotice] = useState<Notice>(null);
  const shown = selectedCategory ? products.filter((p) => p.category === selectedCategory) : products;
  const add = (product: Product) => { cart.add(product, restaurant.name); setNotice({ type: 'success', text: `${product.name} se sumó al carrito` }); setTimeout(() => setNotice(null), 2500); };
  return <><CustomerHeader cartCount={cart.cart.reduce((a, b) => a + b.quantity, 0)} /><main className="mx-auto max-w-[1120px] px-5 pb-20 lg:px-8">
    <Link href="/" className="mt-7 inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary" data-testid="link-back-restaurants"><ArrowLeft className="h-4 w-4" /> Todos los restaurantes</Link>
    <section className="mt-5 overflow-hidden rounded-3xl bg-card ring-1 ring-border warm-shadow"><div className="relative h-[220px] overflow-hidden sm:h-[280px]"><img src={restaurant.image || '/restaurant-selva.jpg'} alt={restaurant.name} className="h-full w-full object-cover" /><div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/10 to-transparent" /><div className="absolute bottom-6 left-6 right-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end sm:left-9 sm:right-9"><div><Badge tone={restaurant.isOpen ? 'green' : 'red'}>{restaurant.isOpen ? 'Abierto ahora' : 'Cerrado'}</Badge><h1 className="mt-2 font-display text-3xl font-bold text-white sm:text-4xl">{restaurant.name}</h1><p className="mt-1 text-sm text-white/75">{restaurant.cuisine}</p></div><div className="flex gap-2 text-xs font-bold text-primary"><span className="flex items-center gap-1 rounded-full bg-[#f6e6bc] px-3 py-2"><Star className="h-3.5 w-3.5 fill-primary" /> {restaurant.rating.toFixed(1)}</span><span className="flex items-center gap-1 rounded-full bg-[#f6e6bc] px-3 py-2"><Clock3 className="h-3.5 w-3.5" /> {restaurant.deliveryMinutes} min</span></div></div></div><div className="flex items-center gap-2 overflow-x-auto px-6 py-4 sm:px-9">{['Todos', ...categories].map((cat) => <button key={cat} onClick={() => setSelectedCategory(cat === 'Todos' ? '' : cat)} className={`whitespace-nowrap rounded-full px-3.5 py-2 text-xs font-extrabold ${(!selectedCategory && cat === 'Todos') || selectedCategory === cat ? 'bg-primary text-white' : 'text-muted-foreground hover:bg-muted'}`} data-testid={`button-category-${cat}`}>{cat}</button>)}</div></section>
    {notice && <div className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-primary px-4 py-3 text-xs font-bold text-white shadow-xl"><Check className="h-4 w-4 text-secondary" /> {notice.text}</div>}
    <div className="mt-10 flex items-end justify-between"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Carta de hoy</p><h2 className="mt-2 font-display text-2xl font-bold text-primary">Lo que sale de cocina</h2></div><span className="hidden text-xs font-semibold text-muted-foreground sm:block">{products.length} opciones</span></div>
    <div className="mt-5 grid gap-4 md:grid-cols-2">{productsQuery.isLoading ? <LoadingCards count={4} /> : shown.length ? shown.map((product) => <ProductCard key={product.id} product={product} onAdd={() => add(product)} />) : <div className="md:col-span-2"><EmptyState title="Carta en pausa" text="Esta cocina está actualizando sus opciones. Vuelve en un ratito." /></div>}</div>
    {cart.cart.length > 0 && <Link href="/cart" className="fixed bottom-5 right-5 z-40 flex items-center gap-3 rounded-full bg-primary px-5 py-3.5 text-sm font-extrabold text-white shadow-xl transition hover:-translate-y-1" data-testid="link-floating-cart"><ShoppingBag className="h-4 w-4 text-secondary" /> Ver carrito <span className="rounded-full bg-secondary px-2 py-0.5 text-[11px] text-primary">{cart.cart.reduce((a, b) => a + b.quantity, 0)}</span></Link>}
  </main></>;
}

function ProductCard({ product, onAdd }: { product: Product; onAdd: () => void }) {
  return <article className="group flex gap-3 rounded-2xl bg-card p-3 ring-1 ring-border/80 transition hover:ring-secondary warm-shadow sm:gap-4" data-testid={`card-product-${product.id}`}><img src={product.image || '/restaurant-selva.jpg'} alt="" className="h-20 w-20 shrink-0 rounded-xl object-cover sm:h-32 sm:w-32" /><div className="flex min-w-0 flex-1 flex-col py-1"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><div className="flex items-center gap-2">{product.popular && <span className="font-mono-app text-[9px] font-bold uppercase tracking-wide text-accent">Popular</span>}</div><h3 className="mt-1 font-display text-base font-bold leading-tight text-primary sm:text-lg">{product.name}</h3></div><button onClick={onAdd} aria-label={`Agregar ${product.name} al carrito`} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-secondary text-primary transition hover:scale-105 hover:bg-accent hover:text-white" data-testid={`button-add-product-${product.id}`}><Plus className="h-4 w-4" /></button></div><p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">{product.description}</p><p className="mt-auto pt-2 font-mono-app text-sm font-bold text-primary">{money(product.price)}</p></div></article>;
}

// Checkout: calcula subtotal/envío, recoge dirección y crea el pedido en el API.
function CartPage({ cart }: { cart: ReturnType<typeof useCart> }) {
  const [, setLocation] = useLocation();
  const [name, setName] = useState(() => localStorage.getItem('pq-name') || '');
  const [address, setAddress] = useState(() => localStorage.getItem('pq-address') || '');
  const [payment, setPayment] = useState<'cash' | 'yape' | 'card'>('yape');
  const [notice, setNotice] = useState<Notice>(null);
  const createOrder = useCreateOrder();
  const restaurantsQuery = useListRestaurants();
  const restaurants = restaurantsQuery.data?.length ? restaurantsQuery.data : fallbackRestaurants;
  const cartRestaurant = cart.cart[0] ? restaurants.find((restaurant) => restaurant.id === cart.cart[0].restaurantId) : undefined;
  const validCart = cart.cart.every((item) => Number.isFinite(item.price) && item.price >= 0 && Number.isInteger(item.quantity) && item.quantity > 0 && Number.isFinite(item.restaurantId));
  const subtotal = validCart ? cart.cart.reduce((sum, item) => sum + item.price * item.quantity, 0) : 0;
  const hasValidDeliveryFee = !!cartRestaurant && Number.isFinite(cartRestaurant.deliveryFee) && cartRestaurant.deliveryFee >= 0;
  const delivery = subtotal >= 45 ? 0 : cartRestaurant && hasValidDeliveryFee ? cartRestaurant.deliveryFee : 0;
  const total = subtotal + delivery;
  const submit = () => {
    if (!validCart || !Number.isFinite(subtotal) || !Number.isFinite(total)) { setNotice({ type: 'error', text: 'El carrito contiene cantidades o precios no válidos. Revisa el pedido antes de continuar.' }); return; }
    if (!name.trim() || !address.trim() || !cart.cart.length) { setNotice({ type: 'error', text: !cart.cart.length ? 'Agrega algo rico antes de continuar.' : 'Completa tu nombre y dirección de entrega.' }); return; }
    if (subtotal < 45 && !hasValidDeliveryFee) { setNotice({ type: 'error', text: 'No pudimos verificar el costo de envío de este restaurante. Intenta de nuevo.' }); return; }
    localStorage.setItem('pq-name', name); localStorage.setItem('pq-address', address);
    const items: OrderItem[] = cart.cart.map((item) => ({ id: item.id, name: item.name, quantity: item.quantity, price: item.price }));
    createOrder.mutate({ data: { restaurantName: cart.cart[0].restaurantName, customerName: name, total, paymentMethod: payment, deliveryAddress: address, items } }, { onSuccess: (order) => { queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetOrderQueryKey(order.id) }); cart.clear(); setLocation(`/orders/${order.id}`); }, onError: () => setNotice({ type: 'error', text: 'No pudimos confirmar tu pedido. Intenta de nuevo.' }) });
  };
  return <><CustomerHeader cartCount={cart.cart.reduce((a, b) => a + b.quantity, 0)} /><main className="mx-auto max-w-[1120px] px-5 pb-20 pt-8 lg:px-8"><Link href="/" className="inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary" data-testid="link-back-cart"><ArrowLeft className="h-4 w-4" /> Seguir descubriendo</Link><div className="mt-8 grid gap-8 lg:grid-cols-[1fr_390px]"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Último paso</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.05em] text-primary">Tu pedido</h1>{cart.cart.length ? <div className="mt-7 overflow-hidden rounded-2xl bg-card ring-1 ring-border">{cart.cart.map((item) => <div key={item.id} className="flex items-center gap-4 border-b border-border/70 p-4 last:border-0" data-testid={`row-cart-${item.id}`}><img src={item.image || '/restaurant-selva.jpg'} alt="" className="h-16 w-16 rounded-xl object-cover" /><div className="min-w-0 flex-1"><h3 className="font-display font-bold text-primary">{item.name}</h3><p className="text-xs text-muted-foreground">{money(item.price)} · {item.restaurantName}</p></div><div className="flex items-center gap-2 rounded-full bg-muted p-1"><button onClick={() => cart.update(item.id, item.quantity - 1)} className="flex h-7 w-7 items-center justify-center rounded-full bg-card text-primary" data-testid={`button-decrease-${item.id}`}><Minus className="h-3 w-3" /></button><span className="w-4 text-center font-mono-app text-xs font-bold">{item.quantity}</span><button onClick={() => cart.update(item.id, item.quantity + 1)} className="flex h-7 w-7 items-center justify-center rounded-full bg-card text-primary" data-testid={`button-increase-${item.id}`}><Plus className="h-3 w-3" /></button></div><p className="w-16 text-right font-mono-app text-sm font-bold text-primary">{money(item.price * item.quantity)}</p></div>)}</div> : <div className="mt-7"><EmptyState title="Tu carrito está tranquilo" text="Explora las cocinas de Quillabamba y agrega algo que te provoque." action={<Link href="/" className="mt-5 inline-flex rounded-full bg-primary px-4 py-2 text-xs font-bold text-white" data-testid="link-empty-cart">Ver restaurantes</Link>} /></div>}<div className="mt-8 rounded-2xl bg-[#e5dfc8] p-5"><div className="flex gap-3"><MapPin className="mt-0.5 h-5 w-5 text-accent" /><div><p className="text-sm font-bold text-primary">Entregamos en todo Quillabamba</p><p className="mt-1 text-xs leading-5 text-primary/60">El repartidor te llamará al llegar. Revisa bien tu referencia.</p></div></div></div></div><div className="h-fit rounded-2xl bg-card p-6 ring-1 ring-border warm-shadow"><h2 className="font-display text-xl font-bold text-primary">Datos de entrega</h2><div className="mt-5 space-y-4"><label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">¿A nombre de quién?</span><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Tu nombre" className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-accent" data-testid="input-customer-name" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">Dirección y referencia</span><textarea value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Ej. Jr. Junín 245, frente a la plaza" className="min-h-[84px] w-full resize-none rounded-xl border border-input bg-background p-3 text-sm outline-none focus:border-accent" data-testid="input-delivery-address" /></label><div><span className="mb-2 block text-xs font-bold text-primary">¿Cómo pagas?</span><div className="grid grid-cols-3 gap-2">{[['yape', 'Yape'], ['cash', 'Efectivo'], ['card', 'Tarjeta']].map(([value, label]) => <button key={value} onClick={() => setPayment(value as typeof payment)} className={`rounded-xl border px-2 py-3 text-xs font-bold ${payment === value ? 'border-primary bg-primary text-white' : 'border-border text-muted-foreground'}`} data-testid={`button-payment-${value}`}>{value === 'yape' ? <Wallet className="mx-auto mb-1 h-4 w-4" /> : value === 'cash' ? <span className="mb-1 block text-center">S/</span> : <CreditCard className="mx-auto mb-1 h-4 w-4" />}{label}</button>)}</div></div></div><div className="my-5 border-t border-border pt-5 font-mono-app text-xs"><div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>{money(subtotal)}</span></div><div className="mt-3 flex justify-between text-muted-foreground"><span>Envío</span><span>{delivery ? money(delivery) : 'Gratis'}</span></div><div className="mt-4 flex justify-between text-base font-bold text-primary"><span>Total</span><span>{money(total)}</span></div></div>{notice && <p className={`mb-3 rounded-lg px-3 py-2 text-xs font-bold ${notice.type === 'error' ? 'bg-red-50 text-red-700' : 'bg-violet-50 text-violet-700'}`} data-testid="status-cart-feedback">{notice.text}</p>}<button onClick={submit} disabled={createOrder.isPending || !cart.cart.length} className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary text-sm font-extrabold text-white transition hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-place-order">{createOrder.isPending ? 'Confirmando...' : 'Confirmar pedido'} <ArrowRight className="h-4 w-4 text-secondary" /></button><p className="mt-3 text-center text-[10px] leading-4 text-muted-foreground">Al confirmar aceptas nuestras condiciones de servicio.</p></div></div></main></>;
}

// Historial del cliente; cada fila lleva al seguimiento de un pedido.
function OrdersPage() {
  const ordersQuery = useListOrders();
  const orders = ordersQuery.data || [];
  return <><CustomerHeader cartCount={0} /><main className="mx-auto max-w-[1000px] px-5 pb-20 pt-10 lg:px-8"><div className="flex items-end justify-between"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Tu ruta</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.05em] text-primary">Mis pedidos</h1><p className="mt-2 text-sm text-muted-foreground">Todo lo que has pedido, en un solo lugar.</p></div><Link href="/" className="hidden items-center gap-2 rounded-full bg-secondary px-4 py-2 text-xs font-bold text-primary sm:flex" data-testid="link-order-more">Pedir algo más <Plus className="h-3.5 w-3.5" /></Link></div><div className="mt-8">{ordersQuery.isLoading ? <LoadingCards count={2} /> : ordersQuery.isError ? <QueryError retry={() => ordersQuery.refetch()} /> : orders.length ? <div className="space-y-3">{orders.map((order) => <OrderRow key={order.id} order={order} />)}</div> : <EmptyState icon={PackageCheck} title="Todavía no hay pedidos" text="Cuando hagas tu primera vuelta por Quillabamba, aparecerá aquí." action={<Link href="/" className="mt-5 inline-flex rounded-full bg-primary px-4 py-2 text-xs font-bold text-white" data-testid="link-empty-orders">Explorar restaurantes</Link>} />}</div></main></>;
}
function OrderRow({ order }: { order: Order }) { return <Link href={`/orders/${order.id}`} className="group flex flex-col gap-4 rounded-2xl bg-card p-5 ring-1 ring-border transition hover:-translate-y-0.5 hover:ring-secondary sm:flex-row sm:items-center" data-testid={`row-order-${order.id}`}><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-secondary text-primary"><ShoppingBag className="h-5 w-5" /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h3 className="truncate font-display text-lg font-bold text-primary">{order.restaurantName}</h3><Badge tone={order.status === 'cancelled' ? 'red' : order.status === 'delivered' ? 'green' : 'orange'}>{statusLabel[order.status]}</Badge></div><p className="mt-1 font-mono-app text-[10px] text-muted-foreground">Pedido #{String(order.id).padStart(4, '0')} · {dateLabel(order.createdAt)} · {order.items.length} productos</p></div><p className="font-mono-app text-sm font-bold text-primary">{money(order.total)}</p><ArrowRight className="hidden h-4 w-4 text-muted-foreground transition group-hover:translate-x-1 sm:block" /></Link>; }

function ServiceRating({ orderId }: { orderId: number }) {
  const storageKey = `quillayaa-rating-${orderId}`;
  const [rating, setRating] = useState(() => Number(localStorage.getItem(storageKey) || 0));
  const [saved, setSaved] = useState(false);
  const rate = (value: number) => {
    localStorage.setItem(storageKey, String(value));
    setRating(value);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };
  return <section className="mt-5 rounded-2xl bg-card p-6 ring-1 ring-border" data-testid="section-service-rating"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Tu experiencia</p><h2 className="mt-2 font-display text-xl font-bold text-primary">Califica el servicio</h2><p className="mt-1 text-xs text-muted-foreground">{rating ? `Registraste ${rating} de 5 estrellas.` : 'Tu opinión ayuda a mejorar la atención y el delivery.'}</p></div><div className="flex items-center gap-2">{[1, 2, 3, 4, 5].map((value) => <button key={value} onClick={() => rate(value)} className={`flex h-10 w-10 items-center justify-center rounded-xl ring-1 transition ${value <= rating ? 'bg-secondary text-primary ring-secondary' : 'bg-background text-muted-foreground ring-border hover:ring-accent'}`} aria-label={`Calificar con ${value} estrellas`} data-testid={`button-rating-${value}`}><Star className={`h-4 w-4 ${value <= rating ? 'fill-primary' : ''}`} /></button>)}</div></div>{saved && <p className="mt-4 rounded-xl bg-violet-50 px-3 py-2 text-xs font-bold text-violet-700">Calificación guardada. Gracias por ayudarnos a mejorar.</p>}</section>;
}

// Seguimiento visual del pedido mediante una línea de estados.
function OrderDetailPage() {
  const { id } = useParams<{ id: string }>(); const orderId = Number(id); const orderQuery = useGetOrder(orderId, { query: { enabled: !!orderId, queryKey: getGetOrderQueryKey(orderId) } }); const order = orderQuery.data;
  const steps: OrderStatus[] = ['received', 'preparing', 'ready', 'on_the_way', 'delivered']; const current = order ? steps.indexOf(order.status) : -1;
  return <><CustomerHeader cartCount={0} /><main className="mx-auto max-w-[960px] px-5 pb-20 pt-8 lg:px-8"><Link href="/orders" className="inline-flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-primary" data-testid="link-back-orders"><ArrowLeft className="h-4 w-4" /> Mis pedidos</Link>{orderQuery.isLoading ? <div className="mt-8 space-y-4"><div className="h-10 w-2/3 animate-pulse-soft rounded bg-muted" /><div className="h-56 animate-pulse-soft rounded-2xl bg-muted" /></div> : orderQuery.isError || !order ? <div className="mt-8"><QueryError retry={() => orderQuery.refetch()} /></div> : <><div className="mt-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Pedido #{String(order.id).padStart(4, '0')}</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.05em] text-primary">{statusLabel[order.status]}</h1><p className="mt-2 text-sm text-muted-foreground">{order.restaurantName} · {dateLabel(order.createdAt)}</p></div><Badge tone={order.status === 'delivered' ? 'green' : order.status === 'cancelled' ? 'red' : 'orange'}>Método de pago: {order.paymentMethod === 'yape' ? 'Yape' : order.paymentMethod === 'card' ? 'Tarjeta' : 'Efectivo'} · Pendiente de confirmación</Badge></div><div className="mt-8 rounded-2xl bg-primary p-6 text-white sm:p-9"><div className="flex items-center justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.16em] text-secondary">Seguimiento en vivo</p><p className="mt-2 text-sm text-white/70">{order.status === 'delivered' ? 'Gracias por pedir local.' : 'Tu pedido está avanzando.'}</p></div><Bike className="h-7 w-7 text-secondary" /></div><div className="mt-10 grid grid-cols-5">{steps.map((step, index) => <div key={step} className="relative text-center"><div className={`relative z-10 mx-auto flex h-8 w-8 items-center justify-center rounded-full border-2 ${index <= current ? 'border-secondary bg-secondary text-primary' : 'border-white/25 bg-primary text-white/45'}`}>{index <= current ? <Check className="h-4 w-4" /> : <span className="font-mono-app text-[10px]">{index + 1}</span>}</div>{index < steps.length - 1 && <div className={`absolute left-[calc(50%+16px)] right-[calc(-50%+16px)] top-4 h-0.5 ${index < current ? 'bg-secondary' : 'bg-white/15'}`} />}<p className={`mt-3 text-[10px] font-bold ${index <= current ? 'text-secondary' : 'text-white/45'}`}>{statusLabel[step]}</p></div>)}</div></div><div className="mt-5 grid gap-5 md:grid-cols-[1fr_270px]"><div className="rounded-2xl bg-card p-6 ring-1 ring-border"><h2 className="font-display text-xl font-bold text-primary">Lo que pediste</h2><div className="mt-4 space-y-3">{order.items.map((item) => <div key={item.id} className="flex justify-between text-sm"><span className="text-muted-foreground"><b className="mr-2 font-mono-app text-xs text-primary">{item.quantity}×</b>{item.name}</span><span className="font-mono-app text-xs font-bold text-primary">{money(item.price * item.quantity)}</span></div>)}</div><div className="mt-5 border-t border-border pt-4 text-sm font-bold text-primary"><div className="flex justify-between"><span>Total</span><span className="font-mono-app">{money(order.total)}</span></div></div></div><div className="rounded-2xl bg-[#e5dfc8] p-6"><MapPin className="h-5 w-5 text-accent" /><p className="mt-4 text-xs font-bold uppercase tracking-wide text-primary/50">Entregar en</p><p className="mt-1 text-sm font-bold leading-5 text-primary">{order.deliveryAddress || 'Dirección no registrada'}</p><p className="mt-5 text-xs font-semibold text-primary/60">A nombre de {order.customerName}</p></div></div>{order.status === 'delivered' && <ServiceRating orderId={order.id} />}</>}</main></>;
}

// Resumen operativo con ventas, pedidos activos y actividad reciente.
function AdminDashboard() {
  const summaryQuery = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const ordersQuery = useListOrders();
  const summary: DashboardSummary = summaryQuery.data || { todaySales: 0, activeOrders: 0, restaurants: 0, deliveryPartners: 0, weeklySales: [] };
  const stats = [{ label: 'Ventas de hoy', value: money(summary.todaySales), icon: Wallet, note: '+12.4% vs. ayer' }, { label: 'Pedidos activos', value: summary.activeOrders, icon: PackageCheck, note: 'En seguimiento' }, { label: 'Restaurantes', value: summary.restaurants, icon: Store, note: 'Aliados activos' }, { label: 'Repartidores', value: summary.deliveryPartners, icon: Bike, note: 'En la calle' }];
  return <AdminShell><div className="animate-rise">
    <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Martes, 24 de junio</p><h1 className="mt-2 font-display text-3xl font-bold tracking-[-.04em] text-primary sm:text-4xl">Buenos días, María.</h1><p className="mt-2 text-sm text-muted-foreground">Así se mueve Pedidos hoy.</p></div><Badge tone="green">● Operativo</Badge></div>
    <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{stats.map(({ label, value, icon: Icon, note }) => <div key={label} className="rounded-2xl bg-card p-5 ring-1 ring-border"><div className="flex items-start justify-between"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary"><Icon className="h-4 w-4" /></div><MoreHorizontal className="h-4 w-4 text-muted-foreground" /></div><p className="mt-5 font-mono-app text-2xl font-bold text-primary">{summaryQuery.isLoading ? '—' : value}</p><p className="mt-1 text-xs font-bold text-primary">{label}</p><p className="mt-2 text-[11px] font-semibold text-violet-700">{note}</p></div>)}</div>
    <div className="mt-6 grid gap-5 xl:grid-cols-[1.25fr_.75fr]">
      <div className="rounded-2xl bg-card p-6 ring-1 ring-border"><div className="flex items-start justify-between"><div><h2 className="font-display text-xl font-bold text-primary">Ventas de la semana</h2><p className="mt-1 text-xs text-muted-foreground">Rendimiento de los últimos 7 días</p></div><span className="rounded-full bg-muted px-3 py-1 font-mono-app text-[10px] font-bold text-muted-foreground">S/ PEN</span></div>
        <div className="mt-8 flex h-[190px] items-end gap-2 sm:gap-4">{(summary.weeklySales.length ? summary.weeklySales : [{ day: 'Lun', total: 0 }, { day: 'Mar', total: 0 }, { day: 'Mié', total: 0 }, { day: 'Jue', total: 0 }, { day: 'Vie', total: 0 }, { day: 'Sáb', total: 0 }, { day: 'Dom', total: 0 }]).map((day, i, arr) => { const max = Math.max(...arr.map((d) => d.total), 1); return <div key={day.day} className="flex flex-1 flex-col items-center gap-2"><div className={`w-full max-w-[42px] rounded-t-lg ${i === arr.length - 2 ? 'bg-accent' : 'bg-secondary'}`} style={{ height: `${Math.max(8, (day.total / max) * 145)}px` }} title={money(day.total)} /><span className="font-mono-app text-[10px] text-muted-foreground">{day.day}</span></div>; })}</div>
      </div>
      <div className="rounded-2xl bg-primary p-6 text-white"><div className="flex items-start justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.16em] text-secondary">Actividad reciente</p><h2 className="mt-2 font-display text-xl font-bold">Pedidos en curso</h2></div><Link href="/admin/orders" className="text-xs font-bold text-secondary" data-testid="link-dashboard-orders">Ver todos</Link></div>
        <div className="mt-6 space-y-4">{ordersQuery.data?.slice(0, 4).map((order) => <Link key={order.id} href={`/admin/orders?order=${order.id}`} className="flex items-center gap-3 border-b border-white/10 pb-3 last:border-0" data-testid={`link-dashboard-order-${order.id}`}><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10"><ShoppingBag className="h-3.5 w-3.5 text-secondary" /></div><div className="min-w-0 flex-1"><p className="truncate text-xs font-bold">{order.restaurantName}</p><p className="mt-0.5 text-[10px] text-white/45">#{order.id} · {statusLabel[order.status]}</p></div><span className="font-mono-app text-xs font-bold">{money(order.total)}</span></Link>)}{!ordersQuery.data?.length && <p className="py-7 text-center text-xs text-white/50">Sin actividad todavía.</p>}</div>
      </div>
    </div>
  </div></AdminShell>;
}

// Gestión administrativa: filtra pedidos y actualiza su estado en el backend.
function AdminOrders() {
  const ordersQuery = useListOrders();
  const update = useUpdateOrderStatus();
  const [filter, setFilter] = useState('all');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);
  const requestedOrderId = Number(new URLSearchParams(window.location.search).get('order'));
  const highlightedOrderId = Number.isSafeInteger(requestedOrderId) && requestedOrderId > 0 ? requestedOrderId : null;
  const orders = (ordersQuery.data || []).filter((order) => filter === 'all' || order.status === filter);
  const filters: Array<[string, string]> = [
    ['all', 'Todos'], ['received', 'Recibidos'], ['preparing', 'En cocina'],
    ['ready', 'Listos'], ['on_the_way', 'En camino'], ['delivered', 'Entregados'], ['cancelled', 'Cancelados'],
  ];
  const change = (orderId: number, status: string) => update.mutate(
    { orderId, data: { status: status as OrderStatusInputStatus } },
    {
      onSuccess: (order) => {
        queryClient.setQueryData(getListOrdersQueryKey(), (old: Order[] | undefined) => old?.map((current) => current.id === order.id ? order : current));
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetOrderQueryKey(order.id) });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        setNotice({ type: 'success', text: `Pedido #${order.id} actualizado` });
      },
      onError: () => setNotice({ type: 'error', text: 'No se pudo actualizar el pedido.' }),
    },
  );
  return <AdminShell><div className="animate-rise">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Operaciones</p><h1 className="mt-2 font-display text-3xl font-bold text-primary">Gestión de pedidos</h1><p className="mt-2 text-sm text-muted-foreground">Mantén cada entrega avanzando.</p></div>
      <button type="button" onClick={() => setFiltersOpen((open) => !open)} aria-expanded={filtersOpen} aria-controls="admin-order-filters" className="flex items-center gap-2 self-start rounded-xl bg-card px-3 py-2.5 text-xs font-bold text-primary ring-1 ring-border sm:self-auto" data-testid="button-order-filters"><SlidersHorizontal className="h-4 w-4" /> Filtros</button>
    </div>
    {notice && <p className={`mt-5 rounded-xl px-4 py-3 text-xs font-bold ${notice.type === 'error' ? 'bg-red-50 text-red-700' : 'bg-violet-50 text-violet-700'}`} data-testid="status-admin-feedback">{notice.text}</p>}
    {filtersOpen && <div id="admin-order-filters" className="mt-7 flex gap-2 overflow-x-auto pb-1" aria-label="Filtrar pedidos por estado">
      {filters.map(([value, label]) => <button key={value} type="button" onClick={() => setFilter(value)} aria-pressed={filter === value} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-bold ${filter === value ? 'bg-primary text-white' : 'bg-card text-muted-foreground ring-1 ring-border'}`} data-testid={`button-admin-filter-${value}`}>{label}</button>)}
    </div>}
    <div className="mt-5 overflow-x-auto rounded-2xl bg-card ring-1 ring-border"><table className="w-full min-w-[720px] text-left"><thead className="border-b border-border bg-muted/50"><tr className="font-mono-app text-[10px] uppercase tracking-wide text-muted-foreground"><th className="px-5 py-4">Pedido</th><th className="px-5 py-4">Cliente</th><th className="px-5 py-4">Total</th><th className="px-5 py-4">Estado</th><th className="px-5 py-4 text-right">Acción</th></tr></thead>
      <tbody>{orders.map((order) => <tr key={order.id} className={`border-b border-border/70 last:border-0 ${highlightedOrderId === order.id ? 'bg-secondary/30' : ''}`} data-highlighted={highlightedOrderId === order.id || undefined} data-testid={`row-admin-order-${order.id}`}><td className="px-5 py-4"><p className="text-sm font-bold text-primary">#{String(order.id).padStart(4, '0')}</p><p className="mt-1 text-[10px] text-muted-foreground">{dateLabel(order.createdAt)}</p></td><td className="px-5 py-4"><p className="text-sm font-bold text-primary">{order.customerName}</p><p className="mt-1 text-[11px] text-muted-foreground">{order.restaurantName}</p></td><td className="px-5 py-4 font-mono-app text-xs font-bold text-primary">{money(order.total)}</td><td className="px-5 py-4"><Badge tone={order.status === 'delivered' ? 'green' : order.status === 'cancelled' ? 'red' : 'orange'}>{statusLabel[order.status]}</Badge></td><td className="px-5 py-4 text-right"><select value={order.status} onChange={(event) => change(order.id, event.target.value)} className="rounded-lg border border-input bg-background px-2 py-2 text-xs font-bold text-primary outline-none" data-testid={`select-status-${order.id}`}><option value="received">Recibido</option><option value="preparing">En cocina</option><option value="ready">Listo</option><option value="on_the_way">En camino</option><option value="delivered">Entregado</option><option value="cancelled">Cancelado</option></select></td></tr>)}</tbody></table>
      {!ordersQuery.isLoading && !orders.length && <div className="p-6"><EmptyState title="Nada por aquí" text="No hay pedidos con este filtro todavía." /></div>}
    </div>
  </div></AdminShell>;
}

function AdminRestaurants() {
  const query = useListRestaurants();
  const restaurants = query.data || [];
  return <AdminShell><div className="animate-rise">
    <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-end"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Red local</p><h1 className="mt-2 font-display text-3xl font-bold text-primary">Restaurantes</h1><p className="mt-2 text-sm text-muted-foreground">Los aliados que hacen posible cada pedido.</p></div><Link href="/admin/manage?tab=businesses" className="flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-xs font-bold text-white" data-testid="button-add-restaurant"><Plus className="h-4 w-4 text-secondary" /> Gestionar negocios</Link></div>
    <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{query.isLoading ? <LoadingCards /> : restaurants.length ? restaurants.map((restaurant) => <div key={restaurant.id} className="rounded-2xl bg-card p-4 ring-1 ring-border" data-testid={`card-admin-restaurant-${restaurant.id}`}><div className="flex gap-3"><img src={restaurant.image || '/restaurant-selva.jpg'} alt="" className="h-16 w-16 rounded-xl object-cover" /><div className="min-w-0 flex-1"><div className="flex justify-between gap-2"><h3 className="truncate font-display text-lg font-bold text-primary">{restaurant.name}</h3><Badge tone={restaurant.isOpen ? 'green' : 'red'}>{restaurant.isOpen ? 'Activo' : 'Pausado'}</Badge></div><p className="mt-1 text-xs text-muted-foreground">{restaurant.cuisine}</p></div></div><div className="mt-4 flex justify-between border-t border-border pt-3 font-mono-app text-[10px] text-muted-foreground"><span>★ {restaurant.rating.toFixed(1)}</span><span>{restaurant.deliveryMinutes} min promedio</span><Link href="/admin/manage?tab=businesses" className="font-bold text-accent" data-testid={`button-edit-restaurant-${restaurant.id}`}>Abrir gestión</Link></div></div>) : <div className="sm:col-span-2 lg:col-span-3"><EmptyState icon={Store} title="Aún no hay aliados" text="Cuando una cocina se sume, aparecerá aquí." /></div>}</div>
  </div></AdminShell>;
}
function AdminDelivery() {
  const [partners] = useState([{ name: 'Luis Cárdenas', zone: 'Centro · La Granja', status: 'En ruta', orders: 3, initials: 'LC' }, { name: 'Rosa Huamán', zone: 'Pueblo Nuevo', status: 'Disponible', orders: 0, initials: 'RH' }, { name: 'Jhonatan Tello', zone: 'Lares · Sambaray', status: 'En ruta', orders: 2, initials: 'JT' }]);
  return <AdminShell><div className="animate-rise">
    <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-end"><div><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Última milla</p><h1 className="mt-2 font-display text-3xl font-bold text-primary">Repartidores</h1><p className="mt-2 text-sm text-muted-foreground">La ciudad se mueve con ellos.</p></div><Link href="/admin/manage?tab=couriers" className="flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-xs font-bold text-white" data-testid="button-add-delivery"><Plus className="h-4 w-4 text-secondary" /> Gestionar repartidores</Link></div>
    <div className="mt-7 rounded-2xl bg-primary p-6 text-white"><div className="flex items-center justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.16em] text-secondary">Cobertura de hoy</p><p className="mt-2 font-display text-2xl font-bold">Quillabamba está cubierta</p></div><MapPin className="h-7 w-7 text-secondary" /></div><div className="mt-6 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[76%] rounded-full bg-secondary" /></div><div className="mt-3 flex justify-between text-[11px] text-white/60"><span>76% de repartidores activos</span><span>5 de 6 zonas</span></div></div>
    <div className="mt-6 grid gap-4 lg:grid-cols-3">{partners.map((partner) => <div key={partner.name} className="rounded-2xl bg-card p-5 ring-1 ring-border" data-testid={`card-delivery-${partner.initials}`}><div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-full bg-secondary font-display font-bold text-primary">{partner.initials}</div><div><h3 className="font-bold text-primary">{partner.name}</h3><p className="mt-1 text-xs text-muted-foreground">{partner.zone}</p></div></div><div className="mt-5 flex items-center justify-between border-t border-border pt-4"><Badge tone={partner.status === 'Disponible' ? 'green' : 'orange'}>{partner.status}</Badge><span className="font-mono-app text-xs text-muted-foreground">{partner.orders} pedidos hoy</span></div></div>)}</div>
  </div></AdminShell>;
}

function AuthPage({ mode }: { mode: 'login' | 'register' }) { const [, setLocation] = useLocation(); const [email, setEmail] = useState(''); const [name, setName] = useState(''); const [notice, setNotice] = useState(''); const submit = () => { if (!email.includes('@') || (mode === 'register' && !name.trim())) { setNotice('Revisa los datos marcados antes de continuar.'); return; } if (mode === 'register') localStorage.setItem('pq-name', name); setLocation('/'); }; return <div className="paper-grid min-h-[100dvh] bg-background px-5 py-6"><Link href="/" className="mx-auto flex max-w-[1100px] items-center gap-3" data-testid="link-auth-brand"><Mark /><span className="font-display text-lg font-bold text-primary">Pedidos<span className="text-accent">.</span></span></Link><div className="mx-auto mt-12 grid max-w-[1000px] overflow-hidden rounded-3xl bg-card ring-1 ring-border warm-shadow md:grid-cols-[.9fr_1.1fr]"><div className="relative hidden min-h-[560px] overflow-hidden bg-primary md:block"><img src="/hero-quillabamba.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-45" /><div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/65 to-primary/10" /><div className="relative flex h-full flex-col justify-between p-10"><div className="font-mono-app text-[10px] uppercase tracking-[.18em] text-secondary">Pedidos Quillabamba</div><div><h1 className="max-w-sm font-display text-4xl font-bold leading-tight text-white">Tu ciudad,<br /><span className="text-secondary">a un pedido</span><br />de distancia.</h1><p className="mt-4 max-w-xs text-sm leading-6 text-white/60">Comida local, entregada con el cuidado de alguien que conoce tu barrio.</p></div></div></div><div className="p-7 sm:p-12"><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.18em] text-accent">{mode === 'login' ? 'Qué gusto verte' : 'Una vuelta nueva'}</p><h2 className="mt-3 font-display text-3xl font-bold tracking-[-.04em] text-primary">{mode === 'login' ? 'Inicia sesión' : 'Crea tu cuenta'}</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">{mode === 'login' ? 'Guarda tus direcciones y sigue tus pedidos sin perderte.' : 'Pide más rápido y guarda tus lugares favoritos.'}</p><div className="mt-8 space-y-4">{mode === 'register' && <label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">Tu nombre</span><input value={name} onChange={(e) => setName(e.target.value)} className="h-12 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-accent" placeholder="María" data-testid="input-register-name" /></label>}<label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">Correo electrónico</span><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="h-12 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-accent" placeholder="tu@correo.com" data-testid="input-auth-email" /></label>{mode === 'login' && <label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">Contraseña</span><input type="password" className="h-12 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-accent" placeholder="••••••••" data-testid="input-auth-password" /></label>}</div>{notice && <p className="mt-4 text-xs font-bold text-red-700" data-testid="status-auth-feedback">{notice}</p>}<button onClick={submit} className="mt-7 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary text-sm font-extrabold text-white" data-testid="button-auth-submit">{mode === 'login' ? 'Entrar a mi cuenta' : 'Empezar a pedir'} <ArrowRight className="h-4 w-4 text-secondary" /></button><p className="mt-6 text-center text-xs text-muted-foreground">{mode === 'login' ? '¿Aún no tienes cuenta? ' : '¿Ya tienes cuenta? '}<Link href={mode === 'login' ? '/register' : '/login'} className="font-bold text-accent" data-testid="link-auth-switch">{mode === 'login' ? 'Regístrate' : 'Inicia sesión'}</Link></p></div></div></div>; }

function SettingsPage() { const [name, setName] = useState(() => localStorage.getItem('pq-name') || 'María Quispe'); const [address, setAddress] = useState(() => localStorage.getItem('pq-address') || ''); const [saved, setSaved] = useState(false); const save = () => { localStorage.setItem('pq-name', name); localStorage.setItem('pq-address', address); setSaved(true); setTimeout(() => setSaved(false), 2200); }; return <><CustomerHeader cartCount={0} /><main className="mx-auto max-w-[850px] px-5 pb-20 pt-10 lg:px-8"><p className="font-mono-app text-[10px] font-bold uppercase tracking-[.16em] text-accent">Tu espacio</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.05em] text-primary">Ajustes</h1><p className="mt-2 text-sm text-muted-foreground">Para que la próxima vuelta sea más rápida.</p><div className="mt-8 grid gap-5 md:grid-cols-[220px_1fr]"><aside className="rounded-2xl bg-primary p-5 text-white"><div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary font-display text-xl font-bold text-primary">MQ</div><p className="mt-4 font-bold">{name || 'Tu nombre'}</p><p className="mt-1 text-xs text-white/55">Cliente de Quillabamba</p><div className="mt-7 space-y-1 text-xs font-bold"><div className="rounded-lg bg-white/10 px-3 py-2.5 text-secondary">Perfil</div><div className="px-3 py-2.5 text-white/50">Preferencias</div></div></aside><div className="rounded-2xl bg-card p-6 ring-1 ring-border"><h2 className="font-display text-xl font-bold text-primary">Información personal</h2><div className="mt-6 space-y-4"><label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">Nombre completo</span><input value={name} onChange={(e) => setName(e.target.value)} className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-accent" data-testid="input-settings-name" /></label><label className="block"><span className="mb-1.5 block text-xs font-bold text-primary">Dirección frecuente</span><input value={address} onChange={(e) => setAddress(e.target.value)} className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-accent" placeholder="Tu dirección de entrega" data-testid="input-settings-address" /></label><div className="flex flex-col justify-between gap-3 border-t border-border pt-5 sm:flex-row sm:items-center"><p className="text-xs text-muted-foreground">Se guarda solo en este dispositivo.</p><button onClick={save} className="rounded-full bg-primary px-5 py-2.5 text-xs font-bold text-white" data-testid="button-save-settings">{saved ? 'Guardado' : 'Guardar cambios'}</button></div></div></div></div></main></>; }

// La pantalla inicial redirige a cada persona hacia la plataforma de su rol.
function RoleEntryPage({ cart }: { cart: ReturnType<typeof useCart> }) {
  const [, setLocation] = useLocation();
  useEffect(() => {
    const session = readSession();
    if (session && session.role !== 'cliente') setLocation(roleHome[session.role]);
  }, [setLocation]);
  return <HomePage cart={cart} />;
}

// Mapa de navegación de la aplicación. Wouter mantiene las rutas sin recargar.
/*
function Router() { const cart = useCart(); return <Switch><Route path="/"><RoleEntryPage cart={cart} /></Route><Route path="/restaurant/:id"><RoleGate allowed={['cliente']}><RestaurantPage cart={cart} /></RoleGate></Route><Route path="/cart"><RoleGate allowed={['cliente']}><CartPage cart={cart} /></RoleGate></Route><Route path="/orders"><RoleGate allowed={['cliente']}><OrdersPage /></RoleGate></Route><Route path="/orders/:id"><RoleGate allowed={['cliente']}><OrderDetailPage /></RoleGate></Route><Route path="/business"><RoleGate allowed={['administrador_negocio']}><BusinessPortalPage /></RoleGate></Route><Route path="/admin/system"><RoleGate allowed={['administrador_sistema']}><SystemMapPage /></RoleGate></Route><Route path="/admin/manage"><RoleGate allowed={['administrador_sistema']}><AdminManagementPage /></Route><Route path="/admin"><RoleGate allowed={['administrador_sistema']}><AdminDashboard /></RoleGate></Route><Route path="/admin/orders"><RoleGate allowed={['administrador_sistema']}><AdminOrders /></RoleGate></Route><Route path="/admin/restaurants"><RoleGate allowed={['administrador_sistema']}><AdminRestaurants /></RoleGate></Route><Route path="/admin/delivery"><RoleGate allowed={['administrador_sistema']}><AdminDelivery /></RoleGate></Route><Route path="/delivery"><RoleGate allowed={['repartidor']}><EnhancedDeliveryPortalPage /></Route><Route path="/login"><RoleAuthPage mode="login" /></Route><Route path="/register"><RoleAuthPage mode="register" /></Route><Route path="/forgot-password"><PasswordRecoveryPage /></Route><Route path="/settings"><RoleGate allowed={['cliente']}><SettingsPage /></Route><Route component={NotFound} /></Switch>; }

*/

function Router() {
  const cart = useCart();

  return (
    <Switch>
      <Route path="/"><RoleEntryPage cart={cart} /></Route>
      <Route path="/restaurant/:id"><RoleGate allowed={['cliente']}><RestaurantPage cart={cart} /></RoleGate></Route>
      <Route path="/cart"><RoleGate allowed={['cliente']}><CartPage cart={cart} /></RoleGate></Route>
      <Route path="/orders"><RoleGate allowed={['cliente']}><OrdersPage /></RoleGate></Route>
      <Route path="/orders/:id"><RoleGate allowed={['cliente']}><OrderDetailPage /></RoleGate></Route>
      <Route path="/business"><RoleGate allowed={['administrador_negocio']}><BusinessPortalPage /></RoleGate></Route>
      <Route path="/admin/system"><RoleGate allowed={['administrador_sistema']}><SystemMapPage /></RoleGate></Route>
      <Route path="/admin/manage"><RoleGate allowed={['administrador_sistema']}><AdminManagementPage /></RoleGate></Route>
      <Route path="/admin"><RoleGate allowed={['administrador_sistema']}><AdminDashboard /></RoleGate></Route>
      <Route path="/admin/orders"><RoleGate allowed={['administrador_sistema']}><AdminOrders /></RoleGate></Route>
      <Route path="/admin/restaurants"><RoleGate allowed={['administrador_sistema']}><AdminRestaurants /></RoleGate></Route>
      <Route path="/admin/delivery"><RoleGate allowed={['administrador_sistema']}><AdminDelivery /></RoleGate></Route>
      <Route path="/delivery"><RoleGate allowed={['repartidor']}><EnhancedDeliveryPortalPage /></RoleGate></Route>
      <Route path="/login"><RoleAuthPage mode="login" /></Route>
      <Route path="/register"><RoleAuthPage mode="register" /></Route>
      <Route path="/settings"><RoleGate allowed={['cliente']}><SettingsPage /></RoleGate></Route>
      <Route component={NotFound} />
    </Switch>
  );
}

// Proveedores globales: consultas, tooltips, manejo de errores y notificaciones.
function App() { return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><ErrorBoundary><Router /></ErrorBoundary></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>; }

export default App;